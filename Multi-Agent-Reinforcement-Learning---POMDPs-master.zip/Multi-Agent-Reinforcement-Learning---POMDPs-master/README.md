# Multi-Agent-Reinforcement-Learning---POMDPs
Implementation of a paper focusing on the use of reinforcement learning to scale feasibility of POMDPs
